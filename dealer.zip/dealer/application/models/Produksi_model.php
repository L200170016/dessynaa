<?php 

	defined('BASEPATH') OR exit('No direct script access allowed');

	class Produksi_model extends CI_Model{
	//tampil data
		public function get_all_barang(){
			return $this->db->get('inventory')->result_array();
		}

		public function get_all_habis(){
			return $this->db->query("SELECT * FROM inventory where stok_barang <= 5 ")->result_array();
		}

		public function get_all_produksi(){
			$this->db->select('*');
			$this->db->from('production');
			$this->db->join('inventory','inventory.kode_barang = production.kode_barang');
			return $this->db->get()->result_array();
		}

		public function inputStok(){
			$data = [
				'kode_barang' 	=> $this->input->post('kode_barang'),
                'jumlah'		=> $this->input->post('stok'),
                'tanggal'       => $this->input->post('tanggal')
			];
			
			$this->db->insert('production', $data);
			$kode = $this->input->post('kode_barang');
			
			$where = "kode_barang = '$kode'";		
			$stok = (int)$this->input->post('stok');
			
			$this->db->query("UPDATE inventory SET stok_barang = stok_barang + $stok WHERE ".$where." ");
			
		}

		public function hapusDataProduksi($id_production)
		{
			
			$query = $this->db->query("SELECT jumlah , kode_barang FROM production where id_production = $id_production ")->row_array();
			$stok = $query['jumlah'];
			$kode = $query['kode_barang'];
			
			$this->db->query("UPDATE inventory SET stok_barang = stok_barang - $stok WHERE kode_barang = '$kode' ");

			$this->db->where('id_production', $id_production);
			$this->db->delete('production');
		}


		public function getProduksibyId($id_production)
		{
			
			return $this->db->query("SELECT * FROM production inner join inventory WHERE production.id_production = $id_production and production.kode_barang = inventory.kode_barang")->row_array();
		}

		public function ubahdata()
		{

			$data = [
				'kode_barang' 	=> $this->input->post('kode_barang'),
                'jumlah'		=> $this->input->post('stok')
			];
			
			$this->db->where('id_production', $this->input->post('id'));
			$this->db->update('production', $data);

			$kode = $this->input->post('kode_barang');
			$stoklama = (int)$this->input->post('stoklama');
			$where = "kode_barang = '$kode'";		
			$stok = (int)$this->input->post('stok');
			
			$stoklamaa = (int)$this->input->post('stoklama');
			$stokb = (int)$this->input->post('stok');

			//update inventory jika stok pada produksi diubah
			$this->db->query("UPDATE inventory SET stok_barang = (stok_barang - $stoklama) + $stok WHERE ".$where." ");
			
			$kodelama = $this->input->post('kodelama');

			//update stok di inventory apabila kode barang di produksi diubah sehingga stok pada kode barang sebelumnya harus dikurangi
			//$this->db->query("UPDATE inventory SET stok_barang = stok_barang - $stoklamaa WHERE kode_barang = '$kodelama' ");

			//update stok di inventory apabila kode barang di produksi di ubah 
			//$this->db->query("UPDATE inventory SET stok_barang = stok_barang + $stokb WHERE kode_barang = '$kode' ");
			

		}


	}