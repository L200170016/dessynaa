<?php
class M_pos extends CI_Model{
    public function tampil_data()
    {
        return $this->db->get('sales');
    }
	function get_data_barang_bykode($kode_barang){
		$hsl=$this->db->query("SELECT * FROM inventory WHERE kode_barang='$kode_barang'");
		if($hsl->num_rows()>0){
			foreach ($hsl->result() as $data) {
				$hasil=array(
					'kode_barang' => $data->kode_barang,
					'nama_barang' => $data->nama_barang,
					'harga_barang' => $data->harga_barang,
					);
			}
		}
		return $hasil;
    }
	
	function get_data_barang_byid($KTP){
		$hsl=$this->db->query("SELECT * FROM customer WHERE KTP='$KTP'");
		if($hsl->num_rows()>0){
			foreach ($hsl->result() as $data) {
				$hasil=array(
					'KTP' => $data->KTP,
					'pembayaran' => $data->pembayaran,
					);
			}
		}
		return $hasil;
    }
 


	public function input_data($data, $table){
		$this->db->insert($table,$data);
    }
    
	public function insert($data)
	{
		return $this->db->insert("sales", $data);
	}

   

}

