<?php
class M_marketing extends CI_Model{
    public function tampil_data()
    {
        return $this->db->get('marketing');
    }

    public function input_data($data, $table){
		$this->db->insert($table,$data);
    }
    
    public function hapus_data($where, $table){
        $this->db->where($where);
        $this->db->delete($table);
    }
    
    public function edit_data($where, $table){
        return $this->db->get_where($table,$where);
    }
    
    public function update($where,$data){
        $this->db->update('marketing',$where,$data);
    }
    
    public function get_by_id($id_marketing){
        return $this->db->get_where('marketing', array('id_marketing'=>$id_marketing))->row();
    }

    public function detail_data($id_marketing=NULL){
        $query = $this->db->get_where('marketing',array('id_marketing' => $id_marketing))->row();
        return $query;
    }
}


