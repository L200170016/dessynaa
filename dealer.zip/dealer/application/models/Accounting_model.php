<?php 

	defined('BASEPATH') OR exit('No direct script access allowed');

	class Accounting_model extends CI_Model{


        public function get_all_penjualan(){
			$this->db->select('*');
			$this->db->from('sales');
			$this->db->join('inventory','inventory.kode_barang = sales.kode_barang');
			return $this->db->get()->result_array();

		}

		public function total_penjualan(){
			$query = $this->db->query("SELECT sales.total, SUM(total) as total FROM sales");
			return $query->result();
		}

		public function total_laba()
		{
			$query = $this->db->query("SELECT (sales.total - inventory.harga_produksi * sales.jumlah_barang) as laba 
			FROM sales INNER JOIN inventory ON sales.kode_barang = inventory.kode_barang GROUP BY sales.id_sales, sales.kode_barang");
			return $query->result_array();
		}
        
        public function total_produksi()
		{
			$query = $this->db->query("SELECT (inventory.harga_produksi * production.jumlah) as total 
			FROM production INNER JOIN inventory ON production.kode_barang = inventory.kode_barang 
            GROUP BY production.id_production, production.kode_barang");
			return $query->result_array();
		}

		public function cetak()
		{
			$bulan = $this->input->post('bulan');
			$tahun = $this->input->post('tahun');
			
			$query = $this->db->query("SELECT sales.id_sales,sales.tanggal, sales.kode_barang,sales.nama_barang,sales.jumlah_barang, sales.total,inventory.harga_produksi,inventory.harga_barang,(sales.total - inventory.harga_produksi * sales.jumlah_barang) as laba from sales inner join inventory on sales.kode_barang = inventory.kode_barang where month(tanggal) = $bulan and year(tanggal) = $tahun group by sales.id_sales, sales.kode_barang
			");
			return $query->result_array();

		}

		public function labab()
		{
			$bulan = $this->input->post('bulan');
			$tahun = $this->input->post('tahun');

			$query = $this->db->query("SELECT (sales.total - inventory.harga_produksi * sales.jumlah_barang) as laba 
			FROM sales INNER JOIN inventory ON sales.kode_barang = inventory.kode_barang where month(tanggal) = $bulan and year(tanggal) = $tahun GROUP BY sales.id_sales, sales.kode_barang");
			return $query->result_array();
		}

    }