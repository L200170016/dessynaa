<?php
class Pos extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_pos');
	}
	function index(){
			$data['pos'] = $this->m_pos->tampil_data()->
			result();
			$data['title'] = 'Transaksi Penjualan';
        	$data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();

			$this->load->view('templates/header',$data);
			$this->load->view('templates/topbar',$data);
			$this->load->view('templates/sidebar',$data);
			$this->load->view('v_pos',$data);
			$this->load->view('templates/footer');
	
	}
	function get_barang(){
		$kode=$this->input->post('kode');
		$data=$this->m_pos->get_data_barang_bykode($kode);
		echo json_encode($data);
	}

	function get_id(){
		$KTP=$this->input->post('KTP');
		$data=$this->m_pos->get_data_barang_byid($KTP);
		echo json_encode($data);
	}
	public function tambah_aksi(){
		$KTP = $this->input->post('KTP');
        $nama_customer = $this->input->post('nama_customer');
		$alamat_customer = $this->input->post('alamat_customer');
		$telp_customer = $this->input->post('telp_customer');
		$pembayaran = $this->input->post('pembayaran');


        $data = array(
			'KTP' =>$KTP,
			'nama_customer' =>$nama_customer,
			'alamat_customer' =>$alamat_customer,
			'telp_customer'   =>$telp_customer,
			'pembayaran'   =>$pembayaran,
        );

        $this->m_pos->input_data($data,'customer');
        redirect('pos/index');
    }
	
	public function tambah(){
		$KTP = $this->input->post('KTP');
        $kode_barang = $this->input->post('kode_barang');
		$nama_barang = $this->input->post('nama_barang');
		$jumlah_barang = $this->input->post('jumlah_barang');
		$tanggal_transaksi = date('Y-m-d');
		$harga_barang = $this->input->post('harga_barang');
		$pembayaran = $this->input->post('pembayaran');
		$subtotal = $this->input->post('subtotal');
		$total = $this->input->post('total');
        $data = array(
			'KTP' =>$KTP,
			'kode_barang' =>$kode_barang,
			'nama_barang' =>$nama_barang,
			'jumlah_barang'   =>$jumlah_barang,
			'tanggal_transaksi'   =>$tanggal_transaksi,
			'harga_barang' =>$harga_barang,
			'pembayaran' =>$pembayaran,
			'subtotal'   =>$subtotal,
			
        );

        $barang = $this->m_pos->insert($data);
        echo json_encode($barang);
    }

	public function detail($KTP){
        $this->load->model('m_pos');
        $detail = $this->m_marketing->detail_data($KTP);
		$data['detail_pos'] = $detail;
		$data['title'] = 'Detail';
		$data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('detail_pos', $data);
		$this->load->view('templates/footer');
    }
    
}