<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Production extends CI_Controller 
{

    public function index()
    {
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('production/index', $data);
        $this->load->view('templates/footer');
    }

    public function data()
    {
        $data['title'] = 'Data Produksi';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data["barang"] = $this->Produksi_model->get_all_barang();
		$data["produksi"]= $this->Produksi_model->get_all_produksi();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('production/data', $data);
    }

    public function inputStok(){
        $data['title'] = 'Tambah Stok';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();

        $this->form_validation->set_rules('kode_barang', 'Kode_barang', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required');
        
        if ($this->form_validation->run() == FALSE){
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('production/produksi', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Produksi_model->inputStok();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data Berhasil Ditambahkan </div>');
            redirect('production/data');
        }
    }
    
    public function hapus($id_production)
    {
        $this->Produksi_model->hapusDataProduksi($id_production);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data Berhasil Dihapus </div>');
        redirect('production/data');
    }

    public function inventory()
    {
        $data['title'] = 'Inventory';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data["barang"] = $this->Produksi_model->get_all_barang();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('production/inventory', $data);
    }

    public function habis()
    {
        $data['title'] = 'Barang Habis';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data["habis"] = $this->Produksi_model->get_all_habis();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('production/habis', $data);
    }

    public function ubah($id_production)
    {
        $data['title'] = 'Form Ubah Data';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data['barangp'] = $this->Produksi_model->getProduksibyId($id_production);

        $this->form_validation->set_rules('kode_barang', 'Kode_barang', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required');
        
        if ($this->form_validation->run() == FALSE){
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('production/ubahdata', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Produksi_model->ubahdata();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data Berhasil Diubah </div>');
            redirect('production/data');
        }
    }
}