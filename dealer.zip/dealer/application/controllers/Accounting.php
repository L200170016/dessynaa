<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounting extends CI_Controller 
{
    public function index()
    {
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('accounting/index', $data);
        $this->load->view('templates/footer');
    }

    public function penjualan()
    {
        $data['title'] = 'Rekap Penjualan';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data["penjualan"] = $this->Accounting_model->get_all_penjualan();
		$data["total"] = $this->Accounting_model->total_penjualan();
	
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('accounting/penjualan', $data);
 
    }

    public function produksi()
    {
        $data['title'] = 'Rekap Produksi';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data["produksi"] = $this->Produksi_model->get_all_produksi();
		$data["ptotal"] = $this->Accounting_model->total_produksi();
	
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('accounting/produksi', $data);
 
    }

    public function laporan()
    {
        $data['title'] = 'Laporan Laba Rugi';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data["penjualan"] = $this->Accounting_model->get_all_penjualan();
        $data["total"] = $this->Accounting_model->total_penjualan();
        $data["tlaba"] = $this->Accounting_model->total_laba();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('accounting/laporan', $data);
 
    }

    public function cetak()
    {
        $data['title'] = 'Laporan Keuangan';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();
        $data['cetak'] = $this->Accounting_model->cetak();
        $data['labab'] = $this->Accounting_model->labab();

        //load view yang akan digenerate atau diconvert
        $this->load->view('accounting/cetak',$data);
        
    }



}