<?php
class Marketing extends CI_Controller{
    public function index(){
        $data['marketing'] = $this->m_marketing->tampil_data()->
        result();
        $data['title'] = 'Strategi';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('marketing', $data);
		$this->load->view('templates/footer');
    }

    public function tambah_aksi(){
        $strategi = $this->input->post('strategi');
        $gambar   = $_FILES['gambar'];
        if($gambar=''){}else{
            $config['upload_path']  = './assets/gambar';
            $config['allowed_types'] ='jpg|png|gif';

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('gambar')){
                echo "Upload Gagal"; die();
            }else{
                $gambar=$this->upload->data('file_name');
            }
        }

        $data = array(
            'strategi' =>$strategi,
            'gambar'   =>$gambar,
        );

        $this->m_marketing->input_data($data,'marketing');
        redirect('marketing/index');
    }

    public function hapus($id_marketing){
        $where = array ('id_marketing'=>$id_marketing);
        $this->m_marketing->hapus_data($where, 'marketing');
        redirect('marketing/index');
    }

    public function edit($id_marketing){
        $where = array ('id_marketing'=>$id_marketing);
        $data['marketing'] = $this->m_marketing->edit_data($where,'marketing')->result();
        $data['title'] = 'Edit Data';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('edit_marketing', $data);
		$this->load->view('templates/footer');
    }

    public function update(){
            $config['upload_path']         = './assets/gambar/';  // foler upload 
            $config['allowed_types']        = 'gif|jpg|png'; // jenis file
     
 
            $this->load->library('upload', $config);
 
            if ( !$this->upload->do_upload('gambar')) //sesuai dengan name pada form 
            {
                   echo 'anda belum upload';
            }
            else
            {
                //tampung data dari form
                $strategi = $this->input->post('strategi');
                $file = $this->upload->data();
                $gambar = $file['file_name'];
 
                $this->m_marketing->update(array(
                    'strategi' => $strategi,
                    'gambar' => $gambar), array('id_marketing'=> $this->input->post('id_marketing')
                        )
                );
                redirect('marketing/index');
            }
            
            $data['tampil']=$this->m_marketing->get_by_id($id_marketing); 
            $this->load->view('edit_marketing',$data);
    }

    public function detail($id_marketing){
        $this->load->model('m_marketing');
        $detail = $this->m_marketing->detail_data($id_marketing);
        $data['detail_marketing'] = $detail;
        $data['title'] = 'Detail';
        $data['user'] = $this->db->get_where('akun', ['username' => $this->session->userdata('username')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('detail_marketing', $data);
		$this->load->view('templates/footer');
    }
}