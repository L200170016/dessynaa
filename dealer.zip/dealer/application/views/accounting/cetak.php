<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title><?= $title; ?></title>

  <!-- Favicons -->
  <link href="<?= base_url('assets/'); ?>img/favicon.png" rel="icon">
  <link href="<?= base_url('assets/'); ?>img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?= base_url('assets/'); ?>lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="<?= base_url('assets/'); ?>lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link href="<?= base_url('assets/'); ?>lib/advanced-datatable/css/demo_page.css" rel="stylesheet" />
  <link href="<?= base_url('assets/'); ?>lib/advanced-datatable/css/demo_table.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?= base_url('assets/'); ?>lib/advanced-datatable/css/DT_bootstrap.css" />
  <!-- Custom styles for this template -->
  <link href="<?= base_url('assets/'); ?>css/style.css" rel="stylesheet">
  <link href="<?= base_url('assets/'); ?>css/style-responsive.css" rel="stylesheet">

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body onload="window.print();">
<?php
      $tanggal = date('d F Y');
      $bulan = $this->input->post('bulan');
	    $tahun = $this->input->post('tahun');
  ?>
<section id="container">
      <section class="wrapper">
        <div class="content-panel col-md-12">
        <center><h3>Laporan Keuangan Bulan <?= $bulan; ?> Tahun <?=$tahun; ?></h3></center>
        <div class="row mb">
          <!-- page start-->
            <div class="adv-table">
              <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Tanggal</th>
                    <th>Kode Barang</th>    
                    <th>Nama Barang</th>
                    <th>Jumlah Penjualan</th>
                    <th>Harga Barang</th>
                    <th>Harga Produksi</th>
                    <th>Total</th>
                    <th>Laba / Rugi</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; foreach($cetak as $ctk) {?>
                  <tr class="gradeX">
                    <td><?php echo $i?></td>
                    <td><?php echo date("d/m/Y", strtotime($ctk['tanggal']));?></td>
                    <td><?php echo $ctk['kode_barang'];?></td>
                    <td><?php echo $ctk['nama_barang'];?></td>
                    <td><?php echo $ctk['jumlah_barang'];?></td>
                    <td> Rp. <?php echo number_format ($ctk['harga_barang']);?></td>
                    <td> Rp. <?php echo number_format ($ctk['harga_produksi']);?></td>
                    <td> Rp. <?php echo number_format ($ctk['total']);?></td>
                    <td> Rp. <?php echo number_format ($ctk['total']-$ctk['harga_produksi']*$ctk['jumlah_barang']);?></td>
                  </tr>
                  <?php $i++; } ?>
                  <tr>
                    <?php
                     $total = 0;
                     foreach($labab as $value)
                       $total += $value['laba'] ?>
                      <td colspan = 8 align = "right">Total Laba : </td>
                      <td><b> Rp. <?php echo number_format ($total);?></b></td>
                    </tr>
                </tbody>
              </table>
            </div> <br><br><br><br>
            <p class="lead text-red pull-right"> Boyolali, <?=$tanggal; ?></p><br><br><br><br><br>
            <p class="lead text-red pull-right"> <?= $user['nama'];?>
          
          <!-- page end-->
          
        </div>
        </div>
        </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    </body>
</html>