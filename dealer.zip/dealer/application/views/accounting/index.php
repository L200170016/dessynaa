
 
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> <?= $title; ?></h3>
        <div class="row mt">
          <div class="col-lg-12">
          <div class="card mb-3" style="max-width: 540px;">
              <div class="row no-gutters">
                <div class="col-md-4">
                  <img src="<?= base_url('assets/img/profile/') . $user['foto']; ?>" class="card-img" >
                </div>
                <div class="col-md-2">
                </div>
                <div class="col-md-6">
                  <div class="card-body">
                    <h5 class="card-title">Nama : <?= $user['nama']; ?></h5>
                    <p class="card-text">Username : <?= $user['username']; ?></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    