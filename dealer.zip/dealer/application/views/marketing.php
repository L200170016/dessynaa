<section id="main-content">
<section class="wrapper">
        <div class="row">
            <div class="col-lg-12 main-chart">
            <!--CUSTOM CHART START -->
            <div class="border-head">
              <h3>DASHBOARD</h3>
            </div>
            </div>
        </div>
        <button class="btn btn-success" data-toggle="modal" data-target="#exampleModal"><i class = "fa fa-plus"></i>
            TAMBAH DATA MARKETING</button>
            <hr>
            <div class="content-panel">
            <div class="adv-table">
            <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Strategi</th>
                    <th>Gambar</th>
                    <th colspan=3>Aksi</th>
                  </tr>
                  <?php 

                  $no=1;
                  foreach ($marketing as $mkt):?>
                  <tr>
                    <th><?php echo $no++ ?></th>
                    <th><?php echo $mkt->strategi ?></th>
                    <th><img src="<?=base_url('assets/gambar/'.$mkt->gambar)?>" style ="width:40px"></th>
                    <th><?php echo anchor('marketing/detail/'.$mkt->id_marketing,
                    '<div class="btn btn-success btn-sm"><i class ="fa fa-search-plus"></i></div>')?>
                    <th onclick ="javascript: return confirm('Anda yakin hapus?')">
                    <?php echo anchor('marketing/hapus/'.$mkt->id_marketing,
                    '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?></th>
                    <th><?php echo anchor('marketing/edit/'.$mkt->id_marketing,
                    '<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>')?></th>
                  </tr>
                </thead>
            <?php endforeach;?>
            </table>
            </div>
            </div>
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">FORM INPUT DATA MARKETING</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open_multipart('marketing/tambah_aksi');?>
                <div class="form-group">
                    <label>Strategi</label>
                    <input type ="text" name="strategi" class="form-control">
                </div>
                <div class="form-group">
                    <label>Gambar</label>
                    <input type ="file" name="gambar" class="form-control">
                   
                </div>
                <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
                <button type="submit" class="btn btn-primary">Save</button>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
</section>