<section id="main-content">
<section class="wrapper">
<!DOCTYPE html>
<html>
<head>
	<title>Point Of Sale</title>
</head>
<body>
	<div class="container">
		<div class="col-md-12 col-md-offset-1">
		  <hr/>

<html>
<head>
<title>Tambah baris dengan jQuery</title>
<script src="development-bundle/jquery-1.6.2.js">
</script>
<script>
function tambah_baris()
{
	html='<tr>'
	+ '<td><input type="text" class="form-control  id = "kode_barang" name="kode_barang"></td>'
	+ '<td><input type="text" class="form-control  id = "nama_barang" name="nama_barang"></td>'
  + '<td><input type="text"  class="form-control  id = "harga_barang"name="harga_barang"></td>'
	+ '<td><input type="number"  class="form-control  id = "jumlah_barang"name="jumlah_barang"></td>'
  + '<td><input type="text"  class="form-control  id = "subtotal"name="subtotal"></td>'
	+ '<td><input type="text"  class="form-control  id = "hapus"name="hapus"></td>'
	+ '</tr>';
	$('#table_transaksi tbody').append(html);
}
	
</script>
 </head>
<table action="<?php echo site_url('pos/tambahData')?>"id="table_transaksi" class="table table-striped table-bordered">
    <thead>
    <thead>
      <tr>
        <th colspan = 3>
          <div class="form-group">
            <label class="control-label col-xs-3" >Tanggal</label>
            <div class="col-xs-9">
              <input type="text" class="form-control" style="width:335px;" name="tgl_transaksi" value="<?= date('d-m-Y') ?>" readonly="readonly">
            </div>
          </div>
        </th>
        <th colspan =3>
          <div class="form-group">
            <label class="control-label col-xs-3" >Pembayaran</label>
            <div class="col-xs-9">
                <input name="pembayaran" id="pembayaran" class="form-control" type="text"  style="width:335px;">
            </div>
          </div>
        </th>
      </tr>
      <tr>
        <th colspan =3 >
          <div class="form-group">
            <label class="control-label col-xs-3" >Nama Customer</label>
            <div class="col-xs-9">
                <input name="nama_customer" id="nama_customer" class="form-control" type="text"  style="width:335px;">
            </div>
          </div>
        </th>
        <th colspan = 3>
          <div class="form-group">
            <label class="control-label col-xs-3" >Alamat Customer</label>
            <div class="col-xs-9">
                <input name="alamat_customer" id="alamat_customer" class="form-control" type="text"  style="width:335px;">
            </div>
          </div>
        </th>
      </tr>
      <tr>
      <th colspan = 3>
          <div class="form-group">
            <label class="control-label col-xs-3" >Total Belanja</label>
            <div class="col-xs-9">
               <input name="total" id="total" class="form-control" type="text"  style="width:335px;">
            </div>
          </div>
      </th>
      <th colspan = 3>
        <div class="form-group">
            <label class="control-label col-xs-3" >Telephone Customer</label>
            <div class="col-xs-9">
                <input name="telp_customer" id="telp_customer" class="form-control" type="text"  style="width:335px;">
            </div>
        </div>
      </th>
      </tr>
      <tr>
<thead>
	<tr>
	<td>Kode Barang</td>
	<td>Nama Barang</td>
  <td>Harga Barang</td>
	<td>Jumlah Barang</td>
  <td>Subtotal</td>
  <td>Hapus</td>
	</tr>
</thead>
<tbody>
	<tr>
	<td><input type="text"  class="form-control" id = "kode_barang" name="kode_barang"></td>
	<td><input type="text"  class="form-control" id = "nama_barang" name="nama_barang"></td>
  <td><input type="text"  class="form-control"  id = "harga_barang" name="harga_barang"></td>
	<td><input type="number"  class="form-control" id = "jumlah_barang" name="jumlah_barang"></td>
  <td><input type="text" class="form-control"  id = "subtotal" name="subtotal"></td>
  <td><input type="text"  class="form-control" id ="hapus" name="hapus"></td>
	</tr>
</tbody>

<tfoot>
	<td colspan="5"><input type="button" value="Tambah Baris" onclick="tambah_baris()" /></td>
</tfoot>
</table>
<div class="form-group">
    <label class="control-label col-xs-3" >Tunai</label>
    <div class="col-xs-9">
        <input name="tunai" id="tunai" class="form-control" type="text"  style="width:335px;">
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-xs-3" >Kembalian</label>
    <div class="col-xs-9">
        <input name="kembalian" id="kembalian" class="form-control" type="text"  style="width:335px;">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-md-offset-3 col-md-3">
      <button type="button" class="btn btn-primary" id="save" ><i class="fa fa-cart-plus"></i>Total</button>
    </div>
  </div>

  <div class="form-group">
    <div class="col-md-offset-3 col-md-3">
      <button type="button" class="btn btn-primary" id="c" ><i class="fa fa-cart-plus"></i>Total</button>
    </div>
  </div>

  <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.js'?>"></script>

  <script type="text/javascript">
    $(document).ready(function(){
      var totalbelanja = 0;
      $('#kode_barang').on('input',function(){
        var kode_barang=$(this).val();
        $.ajax({
          type : "POST",
          url  : "<?php echo base_url('index.php/pos/get_barang')?>",
          dataType : "JSON",
          data : {kode: kode_barang},
          cache:false,
          success: function(data){
            $.each(data,function(kode_barang, nama_barang, harga_barang){
              $('[name="nama_barang"]').val(data.nama_barang);
              $('[name="harga_barang"]').val(data.harga_barang);
            });
          }
        });
        return false;
      });


      $( "#jumlah_barang").on("keyup change",function() {
        var sum = 0;
        var harga_barang  = $("#harga_barang").val();
        var jumlah_barang = $("#jumlah_barang").val();
        
        var subtotal = parseInt(harga_barang) * parseInt(jumlah_barang);
        $("#subtotal").val(subtotal);

      });

      
      $("#tunai").on("keyup change", function(){
        var total = $("#total").val();
        var tunai = $("#tunai").val();
        var kembalian = parseInt(tunai) - parseInt(total);
        $("#kembalian").val(kembalian);
      });

     

      $('#save').click(function(){
        var no = $('#no').val();
        var kode_barang = $('#kode_barang').val();
        var nama_barang = $('#nama_barang').val();
        var harga_barang = $('#harga_barang').val();
        var jumlah_barang = $('#jumlah_barang').val();
        var subtotal = $('#subtotal').val();
        
      
        $('#table_transaksi tbody:last-child').append(
          '<tr>'+
              '<td>'+no+'</td>'+
              '<td>'+kode_barang+'</td>'+
              '<td>'+nama_barang+'</td>'+
              '<td>'+harga_barang+'</td>'+
              '<td>'+jumlah_barang+'</td>'+
              '<td>'+subtotal+'</td>'+
          '</tr>'
        );
        totalbelanja += parseInt(subtotal);
        $("#total").val(totalbelanja);

        $("#c").click(function(){
            var nama_customer = $('#nama_customer').val();
            var alamat_customer = $('#alamat_customer').val();
            var telp_customer = $('#telp_customer').val();
            var pembayaran = $('#pembayaran').val();
            var tanggal_transaksi = $('#tanggal_transaksi').val();
            $.ajax({
                url:  "<?php echo base_url('index.php/pos/tambahData')?>",
                type: 'POST',
                data: {nama_customer:nama_customer,alamat_customer:alamat_customer,telp_customer:telp_customer,pembayaran:pembayaran,tanggal_transaksi:tanggal_transaksi},
                success: function(response){
                    $('input[name="nama_customer"]').val("");
                    $('input[name="alamat_customer"]').val("");
                    $('input[name="telp_customer"]').val("");
                    $('input[name="pembayaran"]').val("");
                    $('input[name="tanggal_transaksi"]').val("");
                }
            });
 
        });
      });
    });
    
  </script>
  </body>
</html>
</section>
</section>