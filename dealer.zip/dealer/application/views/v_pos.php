<section id="main-content">
<section class="wrapper">
<!DOCTYPE html>
<html>
<head>
	<title>Point Of Sale</title>
</head>
<body>

<br>
<br>
    <button class="btn btn-success" data-toggle="modal" data-target="#exampleModal"><i class = "fa fa-plus"></i>
            TAMBAH DATA Customer</button>
		  <hr/>
			<form class="form-horizontal"  action="<?php echo base_url('pos/tambah') ?>" method="post" id="form_transaksi">

        <div class="form-group">
          <label class="control-label col-xs-3" >KTP</label>
          <div class="col-xs-9">
              <input name="KTP" id="KTP" class="form-control" type="text"  style="width:335px;" >
          </div>
        </div>
        <div class="form-group">
            <label class="control-label col-xs-3" >Tanggal</label>
            <div class="col-xs-9">
              <input type="text" class="form-control" style="width:335px;" name="tanggal_transaksi" value="<?= date('Y-m-d') ?>" readonly="readonly">
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-xs-3" >Pembayaran</label>
            <div class="col-xs-9">
                <input name="pembayaran" id="pembayaran" class="form-control" type="text"  style="width:335px;"readonly="readonly">
            </div>
          </div>
        </th>
        <div class="form-group">
          <label class="control-label col-xs-3" >Kode Barang</label>
          <div class="col-xs-9">
              <input name="kode_barang" id="kode_barang" class="form-control" type="text" placeholder="Kode Barang..." style="width:335px;">
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-xs-3" >Nama Barang</label>
          <div class="col-xs-9">
              <input name="nama_barang" id="nama_barang"class="form-control" type="text" placeholder="Nama Barang..." style="width:335px;" readonly>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-xs-3" >Harga</label>
          <div class="col-xs-9">
              <input name="harga_barang" id="harga_barang"class="form-control" type="text" placeholder="credit silahkan ganti sesuai pembayaran" style="width:335px;" >
              credit silahkan ganti sesuai pembayaran
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-xs-3" >Jumlah Barang</label>
          <div class="col-xs-9">
            <input type="number" class="form-control" style="width:335px;" id="jumlah_barang" min="0" name="jumlah_barang" placeholder="Isi qty...">
          </div>
        </div>

        <div class="form-group">
            <label class="control-label col-xs-3" >Sub Total</label>
            <div class="col-xs-9">
                <input name="subtotal" id="subtotal" class="form-control" type="text"  style="width:335px;" readonly="readonly">
            </div>
        </div>
      
        
        <div class="form-group">
          <div class="col-md-offset-3 col-md-3">
            <button type="button" class="btn btn-primary" id="add_data" ><i class="fa fa-cart-plus"></i> Tambah</button>
          </div>
        </div>

			</form>
		</div>
	</div>


  <table id="table_transaksi" class="table table-striped table-bordered">
    <thead>
    <thead>
      
      <tr>
   
          <th>Kode Barang</th>
          <th>Nama Barang</th>
          <th>Harga</th>
          <th>Quantity</th>
          <th>Sub Total</th>
 
      </tr>
    </thead>
    <tbody>
    </tbody>
  </table>

  <div class="form-group">
            <label class="control-label col-xs-3" >Total Belanja</label>
            <div class="col-xs-9">
               <input name="total" id="total" class="form-control" type="text"  style="width:335px;">
            </div>
        </div>
  
 
  <div class="form-group">
    <label class="control-label col-xs-3" >Tunai</label>
    <div class="col-xs-9">
        <input name="tunai" id="tunai" class="form-control" type="text"  style="width:335px;">
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-xs-3" >Kembalian</label>
    <div class="col-xs-9">
        <input name="kembalian" id="kembalian" class="form-control" type="text"  style="width:335px;">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-md-offset-3 col-md-3">
      <button type="button" onclick = "window.print()" class="btn btn-primary" id="print" ><i class="fa fa-cart-plus"></i> Print</button>
    </div>
  </div>


  <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.js'?>"></script>

  <script type="text/javascript">
    $(document).ready(function(){
      var totalbelanja = 0;
      $('#KTP').on('input',function(){
        var KTP=$(this).val();
        $.ajax({
          type : "POST",
          url  : "<?php echo base_url('index.php/pos/get_id')?>",
          dataType : "JSON",
          data : {KTP: KTP},
          cache:false,
          success: function(data){
            $.each(data,function(KTP, pembayaran){
              $('[name="pembayaran"]').val(data.pembayaran);
            });
          }
        });
        return false;
      });
      
      $('#kode_barang').on('input',function(){
        var kode_barang=$(this).val();
        $.ajax({
          type : "POST",
          url  : "<?php echo base_url('index.php/pos/get_barang')?>",
          dataType : "JSON",
          data : {kode: kode_barang},
          cache:false,
          success: function(data){
            $.each(data,function(kode_barang, nama_barang, harga_barang){
              $('[name="nama_barang"]').val(data.nama_barang);
              $('[name="harga_barang"]').val(data.harga_barang);
            });
          }
        });
        return false;
      });
    
      
      $( "#jumlah_barang").on("keyup change",function() {
        var sum = 0;
        var harga_barang  = $("#harga_barang").val();
        var jumlah_barang = $("#jumlah_barang").val();
        
        var subtotal = parseInt(harga_barang) * parseInt(jumlah_barang);
        $("#subtotal").val(subtotal);
        
      });

   
      $("#tunai").on("keyup change", function(){
        var total = $("#total").val();
        var tunai = $("#tunai").val();
        var kembalian = parseInt(tunai) - parseInt(total);
        $("#kembalian").val(kembalian);
      });

      var set_number= function(){
        var table_len = $('#table_transaksi tbody tr').length+1;
       
      }


      $('#add_data').click(function(){
        var KTP = $('#KTP').val();
        var pembayaran = $('#pembayaran').val();
        var kode_barang = $('#kode_barang').val();
        var nama_barang = $('#nama_barang').val();
        var harga_barang = $('#harga_barang').val();
        var jumlah_barang = $('#jumlah_barang').val();
        var subtotal = $('#subtotal').val();
        var total = $('#total').val();
        $.ajax({
                url:  "<?php echo base_url('pos/tambah')?>",
                type: 'POST',
                data: {KTP:KTP,pembayaran:pembayaran,total:total,
                kode_barang:kode_barang,harga_barang:harga_barang,nama_barang:nama_barang,
                jumlah_barang:jumlah_barang,
                subtotal:subtotal},
                success: function(response){
                    $('input[name="KTP"]').val();
                    $('input[name="pembayaran"]').val();
                    $('input[name="total"]').val();
                    $('input[name="kode_barang"]').val("");
                    $('input[name="harga_barang"]').val("");
                    $('input[name="nama_barang"]').val("");
                    $('input[name="jumlah_barang"]').val("");
                    $('input[name="subtotal"]').val("");
                    $('input[name="total"]').val();
                }
            });

        $('#table_transaksi tbody:last-child').append(
          '<tr>'+
              '<td>'+kode_barang+'</td>'+
              '<td>'+nama_barang+'</td>'+
              '<td>'+harga_barang+'</td>'+
              '<td>'+jumlah_barang+'</td>'+
              '<td>'+subtotal+'</td>'+
              
          '</tr>'
          
        );

        totalbelanja += parseInt(subtotal);
        $("#total").val(totalbelanja);
 
        $('#kode_barang').val('');
        $('#nama_barang').val('');
        $('#harga_barang').val('');
        $('#jumlah_barang').val('');
        $('#subtotal').val('');

       
       
 

      });
    });
    
  </script>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">FORM INPUT DATA MARKETING</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open_multipart('pos/tambah_aksi');?>
                <div class="form-group">
                    <label>No KTP</label>
                    <input type ="text" name="KTP" class="form-control">
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type ="text" name="nama_customer" class="form-control">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type ="text" name="alamat_customer" class="form-control">
                </div>
                <div class="form-group">
                    <label>Telp</label>
                    <input type ="text" name="telp_customer" class="form-control">
                </div>
                <div class="form-group">
                    <label>Metode Pembayaran</label>
                    <input type ="text" name="pembayaran" class="form-control">
                </div>
                <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
                <button type="submit" class="btn btn-primary">Save</button>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>


</body>
</html>
</section>
</section>

