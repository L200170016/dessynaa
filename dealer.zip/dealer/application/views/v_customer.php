<section id="main-content">
<section class="wrapper">
<!DOCTYPE html>
<html>
<head>
	<title>Point Of Sale</title>
</head>
<body>
	<div class="container">
		<div class="col-md-12 col-md-offset-1">
        <form class="form-horizontal" id="form_transaksi">

          <div class="form-group">
            <label class="control-label col-xs-3" >Nama Customer</label>
            <div class="col-xs-9">
                <input name="nama_customer" id="nama_customer" class="form-control" type="text"  style="width:335px;">
            </div>
          </div>
        </th>
        <th colspan = 3>
          <div class="form-group">
            <label class="control-label col-xs-3" >Alamat Customer</label>
            <div class="col-xs-9">
                <input name="alamat_customer" id="alamat_customer" class="form-control" type="text"  style="width:335px;">
            </div>
          </div>
        </th>
      </tr>
      <tr>
      
      <th colspan = 3>
        <div class="form-group">
            <label class="control-label col-xs-3" >Telephone Customer</label>
            <div class="col-xs-9">
                <input name="telp_customer" id="telp_customer" class="form-control" type="text"  style="width:335px;">
            </div>
        </div>
      </th>
      </tr>