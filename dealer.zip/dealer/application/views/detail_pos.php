<section id="main-content">
      <section class="wrapper">
        <h4><strong>DETAIL DATA MARKETING</strong></h4>
        <br>
        <table class="display table table-bordered">
                <thead>
                <tr>
                      <td> 
                      <img src="<?php echo base_url();?>assets/gambar/<?php echo $detail_marketing->gambar;?>"
                      width = "900" height ="900">
                      </td>
                   </tr>
                  <tr>
                        <td><?php echo $detail_marketing->strategi?></td>
                   </tr>
                  
                </thead>
        </table>

               <a href="<?php echo base_url('marketing')?>" class ="btn btn-primary">Kembali</a>
    </section>

</section