<br>
<br>
<section id="main-content">
      <section class="wrapper">
            <?php foreach($marketing as $mkt) {?>
               
              <?php echo form_open_multipart('marketing/update');?> 
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Stategi</label>
                  <div class="col-sm-10">
                    <input type="hidden"  name="id_marketing" class="form-control" value="<?php echo $mkt->id_marketing?>"> 
                    <input type="text"  name="strategi" class="form-control" value="<?php echo $mkt->strategi?>">
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Gambar</label>
                  <div class="col-sm-10">
                        <div>
                          <img src="<?=base_url('assets/gambar/'.$mkt->gambar)?>" style="width:500px">
                        </div>
                    <input type="file"  name="gambar" class="form-control" value="<?php echo $mkt->gambar?>">
                  </div>
                </div>
                <button type="reset" class="btn btn-danger">Reset</button>
                <button type="submit" class="btn btn-primary">Save</button>
                <?php echo form_close(); ?>
            <?php }?>
        </section>
</section>