   <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <?php
      $tanggal = date('Y-m-d');
    ?>
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> <?= $title; ?></h3>
        <div class="row mt">
          <div class="col-lg-12">
          <div class="card-content">
          <div class="form-panel">
              <form class="form-horizontal style-form" method="post" action="">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Nama Barang</label>
                  <div class="col-sm-10">
                    <select name="kode_barang" type="text" class="form-control">
                            <option value=""></option>
                            <?php foreach($this->Produksi_model->get_all_barang() as $nama){ ?>
                            <option value="<?php echo $nama['kode_barang'];?>"><?php echo $nama['nama_barang'];?></option>
                        <?php } ?>
                    </select>
                  </div>
                </div>
                  <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Stok Barang</label>
                    <div class="col-sm-10">
                        <input name="stok" type="number" class="form-control">
                        <?= form_error('stok', '<small class="text-danger">', '</small>');?>
                  </div>
                        <input name="tanggal" type="hidden" class="form-control" <?php
                          echo "value='$tanggal' ";
                        ?>
                        >
                </div>
                <div class="card-footer" align ="center">
                    <button type="submit" class="btn btn-theme"><i class="fa fa-save"></i> Simpan</button>
                    <button type="reset" class="btn btn-theme04"><i class="fa fa-ban"></i> Batal</button>
                </div>
              </form>
            </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
