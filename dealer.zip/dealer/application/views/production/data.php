  <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> <?= $title; ?></h3>
        <div class="row mb">
          <!-- page start-->
          <div class="content-panel">
          <?= $this->session->flashdata('message'); ?>
            <div class="adv-table">
              <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Tanggal</th>
                    <th>Kode Barang</th>    
                    <th>Nama Barang</th>
                    <th>Jumlah Produksi</th>
                    <th>Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; foreach($produksi as $pks) {?>
                  <tr class="gradeX">
                    <td><?php echo $i?></td>
                    <td><?php echo date("d F Y", strtotime($pks['tanggal']));?></td>
                    <td><?php echo $pks['kode_barang'];?></td>
                    <td><?php echo $pks['nama_barang'];?></td>
                    <td><?php echo $pks['jumlah'];?></td>
                    <td>
                        <a href="<?= base_url();?>production/ubah/<?= $pks['id_production'];?>">
                        <button type="reset" class="btn btn-theme03 btn-xs"><i class="fa fa-edit"></i> Ubah</button></a>
                      <a href="<?= base_url();?>production/hapus/<?= $pks['id_production'];?>" onclick="return confirm('Yakin ingin menghapusnya?')">
                        <button type="reset" class="btn btn-theme04 btn-xs"><i class="fa fa-trash"></i> Hapus</button></a>
                    </td>
                  </tr>
                  <?php $i++; } ?>
                </tbody>
              </table>
            </div>
          </div>
          <!-- page end-->
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->

      <!--footer start-->
<footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>VAKCOV</strong>. All Rights Reserved
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
          Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
        </div>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?= base_url('assets/'); ?>lib/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery.ui.touch-punch.min.js"></script>
  <script type="text/javascript" language="javascript" src="<?= base_url('assets/'); ?>lib/advanced-datatable/js/jquery.js"></script>
  <script class="include" type="text/javascript" src="<?= base_url('assets/'); ?>lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery.scrollTo.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script type="text/javascript" language="javascript" src="<?= base_url('assets/'); ?>lib/advanced-datatable/js/jquery.dataTables.js"></script>
  <script type="text/javascript" src="<?= base_url('assets/'); ?>lib/advanced-datatable/js/DT_bootstrap.js"></script>
  <!--common script for all pages-->
  <script src="<?= base_url('assets/'); ?>lib/common-scripts.js"></script>
  
  
   <!--script for this page-->
  <script type="text/javascript">
    /* Formating function for row details */
    function fnFormatDetails(oTable, nTr) {
      var aData = oTable.fnGetData(nTr);
      var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
      sOut += '<tr><td>Rendering engine:</td><td>' + aData[1] + ' ' + aData[4] + '</td></tr>';
      sOut += '<tr><td>Link to source:</td><td>Could provide a link here</td></tr>';
      sOut += '<tr><td>Extra info:</td><td>And any further details here (images etc)</td></tr>';
      sOut += '</table>';

      return sOut;
    }

    $(document).ready(function() {

      
      /*
       * Initialse DataTables, with no sorting on the 'details' column
       */
      var oTable = $('#hidden-table-info').dataTable({
        "aoColumnDefs": [{
          "bSortable": false,
          "aTargets": [0]
        }],
        "aaSorting": [
          [1, 'asc']
        ]
      });

    });
  </script>
</body>

</html>
