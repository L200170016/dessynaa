   <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> <?= $title; ?></h3>
        <div class="row mt">
          <div class="col-lg-12">
          <div class="card-content">
          <div class="form-panel">
              <form class="form-horizontal style-form" method="post" action="">
              <input name="id" type ="hidden"class="form-control" value="<?= $barangp['id_production'];?>">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Nama Barang</label>
                  <div class="col-sm-10">
                    <select name="kode_barang" type="text" class="form-control">
                            <?php foreach($this->Produksi_model->get_all_barang() as $nama){ ?>
                            <?php if($nama['kode_barang'] == $barangp['kode_barang']) : ?>
                            <option value="<?php echo $nama['kode_barang'];?>" selected><?php echo $nama['nama_barang'];?></option>
                            <?php else: ?>
                            <option value="<?php echo $nama['kode_barang'];?>"><?php echo $nama['nama_barang'];?></option>
                            <?php endif; ?>
                        <?php } ?>
                    </select>
                  </div>
                </div>
                  <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Stok Barang</label>
                    <div class="col-sm-10">
                        <input name="stok" type="number" class="form-control" value="<?= $barangp['jumlah'];?>">
                        <?= form_error('stok', '<small class="text-danger">', '</small>');?>
                  </div>
                </div>
                <input name="tanggal" type ="hidden"class="form-control"value="<?= $barangp['tanggal'];?>">
                <input name="stoklama" type ="hidden"class="form-control"value="<?= $barangp['jumlah'];?>">
                <input name="kodelama" type ="hidden"class="form-control"value="<?= $barangp['kode_barang'];?>">
                <div class="card-footer" align ="center">
                    <button type="submit" class="btn btn-theme" name="ubah"><i class="fa fa-edit"></i> Ubah</button>
                </div>
              </form>
            </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
