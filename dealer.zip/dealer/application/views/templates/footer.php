<!--footer start-->
<footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>VAKCOV</strong>. All Rights Reserved
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
          Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
        </div>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?= base_url('assets/'); ?>lib/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery.ui.touch-punch.min.js"></script>
  <script type="text/javascript" language="javascript" src="<?= base_url('assets/'); ?>lib/advanced-datatable/js/jquery.js"></script>
  <script class="include" type="text/javascript" src="<?= base_url('assets/'); ?>lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery.scrollTo.min.js"></script>
  <script src="<?= base_url('assets/'); ?>lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script type="<?= base_url('assets/'); ?>text/javascript" language="javascript" src="lib/advanced-datatable/js/jquery.dataTables.js"></script>
  <script type="<?= base_url('assets/'); ?>text/javascript" src="lib/advanced-datatable/js/DT_bootstrap.js"></script>
  <!--common script for all pages-->
  <script src="<?= base_url('assets/'); ?>lib/common-scripts.js"></script>
  

</body>

</html>
