-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Jun 2020 pada 16.03
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dealer`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `id_akun` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `foto` varchar(225) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`id_akun`, `nama`, `username`, `password`, `foto`, `role_id`) VALUES
(1, 'Admin', 'admin', 'admin', 'default.jpg', 1),
(2, 'Dessy Nur Azizah', 'dessyna', 'dessyna', 'dessy.jpg', 2),
(3, 'Dessyna', 'dessyna123', 'dessyna123', 'dessyna.jpg', 3),
(4, 'Prihadina Ayunia W', 'prihadina', 'prihadina', 'default.jpg', 4),
(5, 'Prihadina', 'prihadina123', 'prihadina123', 'default.jpg', 5),
(6, 'Hesti Putri Utami', 'hesti', 'hesti', 'default.jpg', 6),
(7, 'Hesti', 'hesti123', 'hesti123', 'default.jpg', 7),
(8, 'Elvy Rahmatillah I', 'elvy', 'elvy', 'default.jpg', 8),
(9, 'Jessica Gustin R', 'jessica', 'jessica', 'default.jpg', 9),
(10, 'Jessica', 'jessica123', 'jessica123', 'default.jpg', 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `idcustomer` int(11) NOT NULL,
  `KTP` varchar(20) NOT NULL,
  `nama_customer` varchar(45) NOT NULL,
  `alamat_customer` varchar(225) NOT NULL,
  `telp_customer` varchar(20) NOT NULL,
  `pembayaran` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`idcustomer`, `KTP`, `nama_customer`, `alamat_customer`, `telp_customer`, `pembayaran`) VALUES
(1, '333', 'budi', 'solo', '0865322', 'cash');

-- --------------------------------------------------------

--
-- Struktur dari tabel `document`
--

CREATE TABLE `document` (
  `id_document` int(11) NOT NULL,
  `kode_document` varchar(45) NOT NULL,
  `nama_file` varchar(45) NOT NULL,
  `kategori` varchar(45) NOT NULL,
  `gambar` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `human_resource`
--

CREATE TABLE `human_resource` (
  `id_pegawai` int(11) NOT NULL,
  `nama_pegawai` varchar(45) NOT NULL,
  `alamat_pegawai` varchar(225) NOT NULL,
  `telp_pegawai` int(45) NOT NULL,
  `jabatan` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `inventory`
--

CREATE TABLE `inventory` (
  `kode_barang` varchar(45) NOT NULL,
  `stok_barang` int(45) NOT NULL,
  `nama_barang` varchar(45) NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `harga_produksi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `inventory`
--

INSERT INTO `inventory` (`kode_barang`, `stok_barang`, `nama_barang`, `harga_barang`, `harga_produksi`) VALUES
('111', 4, 'lalala', 200000, 10000000),
('HND', 7, 'Honda Beat', 10000000, 9000000),
('YMH', 10, 'Mio', 12000000, 10000000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `marketing`
--

CREATE TABLE `marketing` (
  `id_marketing` int(11) NOT NULL,
  `strategi` text NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `marketing`
--

INSERT INTO `marketing` (`id_marketing`, `strategi`, `gambar`) VALUES
(1, 'strategi saat ini adalah', 'logo2.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `payroll`
--

CREATE TABLE `payroll` (
  `id_payroll` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `absensi` int(11) NOT NULL,
  `paydate` date NOT NULL,
  `paymode` varchar(11) NOT NULL,
  `potongan` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `production`
--

CREATE TABLE `production` (
  `id_production` int(11) NOT NULL,
  `kode_barang` varchar(45) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `production`
--

INSERT INTO `production` (`id_production`, `kode_barang`, `jumlah`, `tanggal`) VALUES
(1, 'HND', 6, '2020-05-12'),
(22, 'YMH', 5, '2020-05-14'),
(24, 'HND', 1, '2020-05-14'),
(25, 'YMH', 5, '2020-05-14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `purchasing`
--

CREATE TABLE `purchasing` (
  `id_purchasing` int(11) NOT NULL,
  `nama_vendor` varchar(45) NOT NULL,
  `alamat_vendor` varchar(225) NOT NULL,
  `tanggal` date NOT NULL,
  `harga` int(45) NOT NULL,
  `jumlah` int(45) NOT NULL,
  `nama_barang` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `sales`
--

CREATE TABLE `sales` (
  `id_sales` int(11) NOT NULL,
  `kode_barang` varchar(45) NOT NULL,
  `nama_customer` varchar(45) NOT NULL,
  `alamat_customer` varchar(225) NOT NULL,
  `telp_customer` int(45) NOT NULL,
  `nama_barang` varchar(45) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_barang` int(45) NOT NULL,
  `total` int(11) NOT NULL,
  `pembayaran` varchar(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `sales`
--

INSERT INTO `sales` (`id_sales`, `kode_barang`, `nama_customer`, `alamat_customer`, `telp_customer`, `nama_barang`, `jumlah_barang`, `harga_barang`, `total`, `pembayaran`, `tanggal`) VALUES
(1, 'HND', 'nana', 'solo', 866543, 'Honda Beat', 3, 10000000, 30000000, 'cash', '2020-05-14'),
(2, 'YMH', 'dini', 'sukoharjo', 865432, 'Mio', 1, 12000000, 12000000, 'cash', '2020-05-15'),
(3, 'YMH', 'doni', 'sragen', 866543, 'Mio', 1, 12000000, 9000000, 'cash', '2020-06-03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 2),
(4, 3, 3),
(5, 4, 4),
(6, 5, 5),
(7, 6, 6),
(8, 7, 7),
(9, 8, 8),
(10, 9, 9),
(11, 10, 10),
(12, 1, 2),
(13, 1, 3),
(14, 1, 4),
(15, 1, 5),
(16, 1, 6),
(17, 1, 7),
(18, 1, 8),
(19, 1, 9),
(20, 1, 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'Accounting'),
(3, 'Production'),
(4, 'Marketing'),
(5, 'Sales'),
(6, 'Inventory'),
(7, 'Purchase'),
(8, 'Management'),
(9, 'Resource'),
(10, 'Payroll');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Akuntan'),
(3, 'Produksi'),
(4, 'Marketing'),
(5, 'Sales'),
(6, 'Inventory'),
(7, 'Purchase'),
(8, 'Management'),
(9, 'Resource'),
(10, 'Payroll');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
  `url` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
  `icon` varchar(128) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`) VALUES
(1, 1, 'Dashboard', 'admin', 'fa fa-fw fa-dashboard'),
(2, 2, 'My Profile', 'accounting', 'fa fa-fw fa-user'),
(3, 3, 'My Profile', 'production', 'fa fa-fw fa-user'),
(4, 2, 'Rekap Penjualan', 'accounting/penjualan', 'fa fa-fw fa-credit-card'),
(5, 2, 'Rekap Produksi', 'accounting/produksi', 'fa fa-fw fa-cogs'),
(6, 2, 'Laporan Laba Rugi', 'accounting/laporan', 'fa fa-fw fa-book'),
(7, 3, 'Tambah Stok', 'production/inputStok', 'fa fa-fw fa-tasks'),
(8, 3, 'Data Produksi', 'production/data', 'fa fa-fw fa-th'),
(9, 3, 'Inventory', 'Production/inventory', 'fa fa-fw fa-archive'),
(10, 3, 'Barang Habis', 'production/habis', 'fa fa-fw fa-inbox'),
(11, 5, 'Transaksi Penjualan', 'pos', 'fa fa-fw fa-shopping-cart'),
(12, 4, 'Strategi', 'marketing', 'fa fa-fw fa-line-chart');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indeks untuk tabel `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`idcustomer`);

--
-- Indeks untuk tabel `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id_document`);

--
-- Indeks untuk tabel `human_resource`
--
ALTER TABLE `human_resource`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indeks untuk tabel `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indeks untuk tabel `marketing`
--
ALTER TABLE `marketing`
  ADD PRIMARY KEY (`id_marketing`);

--
-- Indeks untuk tabel `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`id_payroll`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `production`
--
ALTER TABLE `production`
  ADD PRIMARY KEY (`id_production`),
  ADD KEY `kode_barang` (`kode_barang`);

--
-- Indeks untuk tabel `purchasing`
--
ALTER TABLE `purchasing`
  ADD PRIMARY KEY (`id_purchasing`);

--
-- Indeks untuk tabel `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id_sales`),
  ADD KEY `kode_barang` (`kode_barang`);

--
-- Indeks untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `akun`
--
ALTER TABLE `akun`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `customer`
--
ALTER TABLE `customer`
  MODIFY `idcustomer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `document`
--
ALTER TABLE `document`
  MODIFY `id_document` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `human_resource`
--
ALTER TABLE `human_resource`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `marketing`
--
ALTER TABLE `marketing`
  MODIFY `id_marketing` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `payroll`
--
ALTER TABLE `payroll`
  MODIFY `id_payroll` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `production`
--
ALTER TABLE `production`
  MODIFY `id_production` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `purchasing`
--
ALTER TABLE `purchasing`
  MODIFY `id_purchasing` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `sales`
--
ALTER TABLE `sales`
  MODIFY `id_sales` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
