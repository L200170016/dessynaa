$(function(){

    $('.tampilModalUbah').on('click', function(){

        const id = $(this).data('id');
        
        $.ajax({
            url: 'http://localhost/dealer/production/getubah',
            data: {id : id},
            method: 'post',
            dataType : 'json',

            success: function(data){
                $('#nama').val(data.nama);
                $('#stok').val(data.stok);
                $('#stok').val(data.stoklama);
                $('#tanggal').val(data.tanggal);
            }
        });

    });

});